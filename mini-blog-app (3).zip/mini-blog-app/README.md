# Mini Blog App

A Pen created on CodePen.io. Original URL: [https://codepen.io/gshew24/pen/OPLEaPJ](https://codepen.io/gshew24/pen/OPLEaPJ).

Single page web app